import ListView from "@/components/ListView";

export default function ListPage() {
  return <ListView />;
}